import h5py
import numpy as np
import os
import time as t
tag=0
out_data=[]
out_label=[]
out_pid=[]
file=input("input data file:")

count=0
n_count=0
p=open(file,"r")
out=p.read()
p.close()

points=[]
ma=out.split("\n")
#print(ma)
data=[]
label=[]
pid=[]
for j in ma:
	#print(j)
	if count==(len(ma)-1):
		#print(j)
		#t.sleep(5)
		break
	else:
		count+=1
	#print(type(j))
	point=j.split(" ")
	#print(point)
	v=[]
	for i in range(0,3):
		print(point[i])
		v.append(float(point[i]))
		
	data.append(v)
	pid.append(int(float(point[3])))

label.append(int(0))
	#print(data)


if len(data) == len(pid):
	print("correct!!")

out_data.append(data)
out_label.append(label)
out_pid.append(pid)
f=h5py.File("ply_data_train"+str(tag)+".h5","w")
f["data"]=out_data
f["label"]=out_label
f["pid"]=out_pid
f.close()
tag+=1
out_data=[]
out_label=[]
out_pid=[]
del points[:]