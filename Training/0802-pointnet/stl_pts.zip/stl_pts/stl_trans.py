import open3d as o3d
mesh = o3d.io.read_triangle_mesh("SPAI-001-C1.stl")
o3d.io.write_triangle_mesh("SPAI-001-C1.ply", mesh)