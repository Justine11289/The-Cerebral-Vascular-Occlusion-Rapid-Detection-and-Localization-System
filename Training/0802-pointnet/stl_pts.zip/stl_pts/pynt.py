from pyntcloud import PyntCloud
import pyvista as pv
anky = PyntCloud.from_file("SPAI-001-C1.ply")
anky.points
anky_cloud = anky.get_sample("mesh_random", n=8000, rgb=False, normals=True, as_PyntCloud=True)
anky_cloud.to_file("SPAI-001-C1.pts",sep=" ",header=0,index=0)